package ATM;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class OptionMenu extends Account {
    Scanner menuInput = new Scanner(System.in);
    DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");

    HashMap<Integer, Integer> data = new HashMap<>();

    public void getLogin() throws IOException {
        int x = 1;
        do {
            try {
                data.put(9865234, 9876);
                data.put(889561, 1890);
                data.put(8923467, 9074);
                System.out.println("WELCOME TO THE ATM !!");
                System.out.print("Enter the Account Number: ");
                setAccountNumber(menuInput.nextInt());
                System.out.print("Enter your Pin Number: ");
                setPinNumber(menuInput.nextInt());

                boolean found = false;
                for (Map.Entry<Integer, Integer> entry : data.entrySet()) {
                    if (entry.getKey().equals(getAccountNumber()) &&
                        entry.getValue().equals(getPinNumber())) {
                        found = true;
                        getAccountType();
                        break;
                    }
                }
                if (!found) {
                    System.out.println("\nWrong Account Number or Pin Number\n");
                }
            } catch (Exception e) {
                System.out.println("\nInvalid character(s). Only numbers allowed.\n");
                menuInput.nextLine(); // Clear scanner buffer
            }
        } while (x == 1);
    }

    public void getAccountType() {
        System.out.println("Select the Account you want to access: ");
        System.out.println("1 - Checking Account");
        System.out.println("2 - Saving Account");
        System.out.println("3 - Exit");
        System.out.print("Choice: ");

        int selection = menuInput.nextInt();

        switch (selection) {
            case 1:
                getChecking();
                break;
            case 2:
                getSaving();
                break;
            case 3:
                System.out.println("THANK YOU FOR VISITING THE ATM, BYE!!!");
                break;
            default:
                System.out.println("\nInvalid choice\n");
                getAccountType();
        }
    }

    public void getChecking() {
        System.out.println("Checking Account: ");
        System.out.println("1 - View Balance");
        System.out.println("2 - Withdraw Amount");
        System.out.println("3 - Deposit Amount");
        System.out.println("4 - Exit");
        System.out.print("Choice: ");

        int selection = menuInput.nextInt();

        switch (selection) {
            case 1:
                System.out.println("Checking Account Balance: " + moneyFormat.format(getCheckingBalance()));
                getAccountType();
                break;
            case 2:
                getCheckingWithdrawInput();
                getAccountType();
                break;
            case 3:
                getCheckingDepositInput();
                getAccountType();
                break;
            case 4:
                System.out.println("THANK YOU FOR VISITING THE ATM, BYE!!!");
                break;
            default:
                System.out.println("\nInvalid choice\n");
                getChecking();
        }
    }

    public void getSaving() {
        System.out.println("Saving Account: ");
        System.out.println("1 - View Balance");
        System.out.println("2 - Withdraw Amount");
        System.out.println("3 - Deposit Amount");
        System.out.println("4 - Exit");
        System.out.print("Choice: ");

        int selection = menuInput.nextInt();

        switch (selection) {
            case 1:
                System.out.println("Saving Account Balance: " + moneyFormat.format(getSavingBalance()));
                getAccountType();
                break;
            case 2:
                getSavingWithdrawInput();
                getAccountType();
                break;
            case 3:
                getSavingDepositInput();
                getAccountType();
                break;
            case 4:
                System.out.println("THANK YOU FOR VISITING THE ATM, BYE!!!");
                break;
            default:
                System.out.println("\nInvalid choice\n");
                getSaving();
        }
    }

    // Placeholder methods for withdrawing and depositing
    public void getCheckingWithdrawInput() {
        // Implementation here
    }

    public void getCheckingDepositInput() {
        // Implementation here
    }

    public void getSavingWithdrawInput() {
        // Implementation here
    }

    public void getSavingDepositInput() {
        // Implementation here
    }
}

